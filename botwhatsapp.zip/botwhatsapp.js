
const { default: makeWASocket, useSingleFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateWAMessageFromContent, proto } = require('@adiwajshing/baileys');
const { Boom } = require('@hapi/boom');
const P = require('pino');
const { state, saveState } = useSingleFileAuthState('./auth_info.json');

async function startSock() {
  const { version, isLatest } = await fetchLatestBaileysVersion();
  console.log(`Using WA vversion.join('.'), isLatest:{isLatest}`);

  const sock = makeWASocket({
    version,
    logger: P({ level: 'silent' }),
    printQRInTerminal: true,
    auth: state
  });

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    if(qr) {
      console.log('Scan this QR code:', qr);
    }
    if(connection === 'close') {
      const shouldReconnect = (lastDisconnect.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log('Connection closed:', lastDisconnect.error, ', reconnecting:', shouldReconnect);
      if(shouldReconnect) {
        startSock();
      }
      } else if(connection === 'open') {
      console.log('Connected!');
    }
  });

  sock.ev.on('creds.update', saveState);

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if(!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const isGroup = from.endsWith('@g.us');
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

    // Fun menu
    if(text.toLowerCase() === '!menu') {
      const menuMessage = `
*🤖 Fun Menu Bot 🤖*

1. !menu - Tampilkan menu ini
2. halo - Bot akan membalas
3. !grupinfo - Info grup (hanya grup)
4. !owner - Info owner
5. !ping - Cek respon bot
      `;
      await sock.sendMessage(from, { text: menuMessage });
      return;
    }

    // Reply 'halo'
    if(text.toLowerCase() === 'halo') {
      await sock.sendMessage(from, { text: 'Halo juga! Ada yang bisa saya bantu?' });
      return;
    }

    // Grup info command
    if(text.toLowerCase() === '!grupinfo' && isGroup) {
      const metadata = await sock.groupMetadata(from);
      const owner = metadata.owner;
      const participantsCount = metadata.participants.length;
      const desc = metadata.desc || 'Tidak ada deskripsi';
      const info = `*Info Grup*\nNama: metadata.subject:{owner}\nJumlah anggota: participantsCount:{desc}`;
      await sock.sendMessage(from, { text: info });
      return;
    }

    // Owner info
    if(text.toLowerCase() === '!owner') {
      await sock.sendMessage(from, { text: 'Owner Bot: @acapja\nTelegram: https://t.me/acapja' }, { mentions: [msg.key.participant || msg.key.remoteJid] });
      return;
    }

    // Ping
    if(text.toLowerCase() === '!ping') {
      await sock.sendMessage(from, { text: 'Pong! Bot aktif dan responsif.' });
      return;
    }

  });
}

startSock();
